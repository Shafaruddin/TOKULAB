# IO.Swagger.Model.FindCustomer
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CustomerName** | **string** |  | [optional] 
**IDNumber** | **string** |  | [optional] 
**AccountNumber** | **string** |  | [optional] 
**MobileNo** | **string** |  | [optional] 
**EmailAddress** | **string** |  | [optional] 
**TriggeredFrom** | **string** |  | 
**TriggeredBy** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

