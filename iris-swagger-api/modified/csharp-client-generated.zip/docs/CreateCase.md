# IO.Swagger.Model.CreateCase
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CustomerGUID** | **Guid?** |  | 
**CaseTitle** | **string** |  | 
**CaseDetails** | **string** |  | 
**SystemAuthenticated** | **bool?** |  | 
**DateTimeReceived** | **string** |  | 
**IPCCCallExtensionID** | **string** |  | 
**PrimaryCaseOfficer** | **string** |  | 
**Owner** | **string** |  | 
**CaseCategory1** | **Guid?** |  | 
**CaseCategory2** | **Guid?** |  | 
**CaseCategory3** | **Guid?** |  | 
**ContactMode** | **string** |  | 
**CreatedBy** | **string** |  | 
**CreatedOn** | **string** |  | 
**ModifiedBy** | **string** |  | 
**CallBack** | **bool?** |  | 
**TriggeredFrom** | **string** |  | 
**TriggeredBy** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

