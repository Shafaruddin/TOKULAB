# IO.Swagger.Model.GenerateOTP
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Mobile** | **string** |  | 
**TriggeredFrom** | **string** |  | 
**TriggeredBy** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

