# IO.Swagger.Model.UpdateCase
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CaseID** | **string** |  | 
**CustomerGUID** | **Guid?** |  | 
**CaseTitle** | **string** |  | 
**CaseDetails** | **string** |  | 
**SystemAuthenticated** | **bool?** |  | 
**ManualVerification** | **bool?** |  | 
**IPCCCallExtensionID** | **string** |  | 
**Owner** | **string** |  | 
**CaseCategory1** | **Guid?** |  | 
**CaseCategory2** | **Guid?** |  | 
**CaseCategory3** | **Guid?** |  | 
**AdHocCriteria** | **Guid?** |  | 
**FollowupAction** | **string** |  | 
**ContactMode** | **string** |  | 
**ModifiedBy** | **string** |  | 
**FollowupRequired** | **bool?** |  | 
**CaseStatus** | **string** |  | 
**Resolution** | **string** |  | 
**TriggeredFrom** | **string** |  | 
**TriggeredBy** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

