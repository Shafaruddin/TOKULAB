# IO.Swagger.Model.GetCustomer
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IDNumber** | **string** |  | [optional] 
**CustomerGUID** | **Guid?** |  | [optional] 
**SPAAccountNumber** | **string** |  | [optional] 
**Anonymous** | **bool?** |  | [optional] 
**DataSet** | **string** |  | 
**TriggeredFrom** | **string** |  | 
**TriggeredBy** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

