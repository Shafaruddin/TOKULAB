# IO.Swagger.Api.DefaultApi

All URIs are relative to *http://svcsintuatirisservice.sgpoolz.com.sg*

Method | HTTP request | Description
------------- | ------------- | -------------
[**SvcsirissitChallengeOTPPost**](DefaultApi.md#svcsirissitchallengeotppost) | **POST** /svcsirissit/ChallengeOTP | 
[**SvcsirissitCreateCasePost**](DefaultApi.md#svcsirissitcreatecasepost) | **POST** /svcsirissit/CreateCase | 
[**SvcsirissitFindCustomerPost**](DefaultApi.md#svcsirissitfindcustomerpost) | **POST** /svcsirissit/FindCustomer | 
[**SvcsirissitGenerateOTPPost**](DefaultApi.md#svcsirissitgenerateotppost) | **POST** /svcsirissit/GenerateOTP | 
[**SvcsirissitGetCaseAndActivitiesHistoryPost**](DefaultApi.md#svcsirissitgetcaseandactivitieshistorypost) | **POST** /svcsirissit/GetCaseAndActivitiesHistory | 
[**SvcsirissitGetCategoryAndCriteriaGet**](DefaultApi.md#svcsirissitgetcategoryandcriteriaget) | **GET** /svcsirissit/GetCategoryAndCriteria | 
[**SvcsirissitGetCustomerPost**](DefaultApi.md#svcsirissitgetcustomerpost) | **POST** /svcsirissit/GetCustomer | 
[**SvcsirissitUpdateCasePost**](DefaultApi.md#svcsirissitupdatecasepost) | **POST** /svcsirissit/UpdateCase | 

<a name="svcsirissitchallengeotppost"></a>
# **SvcsirissitChallengeOTPPost**
> void SvcsirissitChallengeOTPPost (string xSource, ValidateOTP body = null)



### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SvcsirissitChallengeOTPPostExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: basicAuth
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new DefaultApi();
            var xSource = xSource_example;  // string |  (default to WEBEX)
            var body = new ValidateOTP(); // ValidateOTP |  (optional) 

            try
            {
                apiInstance.SvcsirissitChallengeOTPPost(xSource, body);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.SvcsirissitChallengeOTPPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xSource** | **string**|  | [default to WEBEX]
 **body** | [**ValidateOTP**](ValidateOTP.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="svcsirissitcreatecasepost"></a>
# **SvcsirissitCreateCasePost**
> void SvcsirissitCreateCasePost (string xSource, CreateCase body = null)



### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SvcsirissitCreateCasePostExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: basicAuth
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new DefaultApi();
            var xSource = xSource_example;  // string |  (default to WEBEX)
            var body = new CreateCase(); // CreateCase |  (optional) 

            try
            {
                apiInstance.SvcsirissitCreateCasePost(xSource, body);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.SvcsirissitCreateCasePost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xSource** | **string**|  | [default to WEBEX]
 **body** | [**CreateCase**](CreateCase.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="svcsirissitfindcustomerpost"></a>
# **SvcsirissitFindCustomerPost**
> void SvcsirissitFindCustomerPost (string xSource, FindCustomer body = null)



### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SvcsirissitFindCustomerPostExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: basicAuth
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new DefaultApi();
            var xSource = xSource_example;  // string |  (default to WEBEX)
            var body = new FindCustomer(); // FindCustomer |  (optional) 

            try
            {
                apiInstance.SvcsirissitFindCustomerPost(xSource, body);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.SvcsirissitFindCustomerPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xSource** | **string**|  | [default to WEBEX]
 **body** | [**FindCustomer**](FindCustomer.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="svcsirissitgenerateotppost"></a>
# **SvcsirissitGenerateOTPPost**
> void SvcsirissitGenerateOTPPost (string xSource, GenerateOTP body = null)



### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SvcsirissitGenerateOTPPostExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: basicAuth
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new DefaultApi();
            var xSource = xSource_example;  // string |  (default to WEBEX)
            var body = new GenerateOTP(); // GenerateOTP |  (optional) 

            try
            {
                apiInstance.SvcsirissitGenerateOTPPost(xSource, body);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.SvcsirissitGenerateOTPPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xSource** | **string**|  | [default to WEBEX]
 **body** | [**GenerateOTP**](GenerateOTP.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="svcsirissitgetcaseandactivitieshistorypost"></a>
# **SvcsirissitGetCaseAndActivitiesHistoryPost**
> void SvcsirissitGetCaseAndActivitiesHistoryPost (string xSource, GetCaseAndActivitiesHistory body = null)



### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SvcsirissitGetCaseAndActivitiesHistoryPostExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: basicAuth
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new DefaultApi();
            var xSource = xSource_example;  // string |  (default to WEBEX)
            var body = new GetCaseAndActivitiesHistory(); // GetCaseAndActivitiesHistory |  (optional) 

            try
            {
                apiInstance.SvcsirissitGetCaseAndActivitiesHistoryPost(xSource, body);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.SvcsirissitGetCaseAndActivitiesHistoryPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xSource** | **string**|  | [default to WEBEX]
 **body** | [**GetCaseAndActivitiesHistory**](GetCaseAndActivitiesHistory.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="svcsirissitgetcategoryandcriteriaget"></a>
# **SvcsirissitGetCategoryAndCriteriaGet**
> void SvcsirissitGetCategoryAndCriteriaGet (string xSource)



### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SvcsirissitGetCategoryAndCriteriaGetExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: basicAuth
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new DefaultApi();
            var xSource = xSource_example;  // string |  (default to WEBEX)

            try
            {
                apiInstance.SvcsirissitGetCategoryAndCriteriaGet(xSource);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.SvcsirissitGetCategoryAndCriteriaGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xSource** | **string**|  | [default to WEBEX]

### Return type

void (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="svcsirissitgetcustomerpost"></a>
# **SvcsirissitGetCustomerPost**
> void SvcsirissitGetCustomerPost (string xSource, GetCustomer body = null)



### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SvcsirissitGetCustomerPostExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: basicAuth
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new DefaultApi();
            var xSource = xSource_example;  // string |  (default to WEBEX)
            var body = new GetCustomer(); // GetCustomer |  (optional) 

            try
            {
                apiInstance.SvcsirissitGetCustomerPost(xSource, body);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.SvcsirissitGetCustomerPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xSource** | **string**|  | [default to WEBEX]
 **body** | [**GetCustomer**](GetCustomer.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="svcsirissitupdatecasepost"></a>
# **SvcsirissitUpdateCasePost**
> void SvcsirissitUpdateCasePost (string xSource, UpdateCase body = null)



### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SvcsirissitUpdateCasePostExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: basicAuth
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new DefaultApi();
            var xSource = xSource_example;  // string |  (default to WEBEX)
            var body = new UpdateCase(); // UpdateCase |  (optional) 

            try
            {
                apiInstance.SvcsirissitUpdateCasePost(xSource, body);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.SvcsirissitUpdateCasePost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xSource** | **string**|  | [default to WEBEX]
 **body** | [**UpdateCase**](UpdateCase.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
